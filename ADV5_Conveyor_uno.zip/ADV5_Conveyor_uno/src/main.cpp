#include <Arduino.h>
#include <Sensor.h>
#include <Motor.h>

Sensor sensor_de(6);  // Detect Zone.
Sensor sensor_ul(5);  // Unloading Zone.
Motor conveyorMotor(8,9);
bool manualOverride = false;
String manualCommand = "";

void setup()
{
  Serial.begin(115200);
  Serial.println("Sensor&Motor Init");

  sensor_de.sensorInit();
  sensor_ul.sensorInit();
  conveyorMotor.motorInit();
}

void loop()
{
  if (Serial.available() > 0)
  {
    String command = Serial.readStringUntil('\n');
    command.trim();

    if (command == "conveyor on")
    {
      manualOverride = true;
      manualCommand = "on";
      conveyorMotor.conveyorOn();
      Serial.println("command: Conveyor ON");
    }
    else if (command == "conveyor off")
    {
      manualOverride = true;
      manualCommand = "off";
      conveyorMotor.conveyorOff();
      Serial.println("command: Conveyor OFF");
    }
    else if (command == "auto")
    {
      manualOverride = false;
      manualCommand = "";
      Serial.println("AUTO: Conveyor controlled by sensors");
    }
    else if (command == "sensor check")
    {
      Serial.print("Sensor1: ");
      Serial.print(sensor_de.obDetect() ? "DETECT" : "CLEAR");
      Serial.print(" | Sensor2: ");
      Serial.println(sensor_ul.obDetect() ? "DETECT" : "CLEAR");
    }
    else
    {
      Serial.println("Unknown command");
    }
  }

  if (manualOverride)
  {
    if (manualCommand == "on")
    {
      conveyorMotor.conveyorOn();
    }
    else if (manualCommand == "off")
    {
      conveyorMotor.conveyorOff();
    }
    delay(300);
    return;
  }

  bool s1 = sensor_de.obDetect();
  bool s2 = sensor_ul.obDetect();

  if (s1 || s2)
  {
    delay(2100);
    conveyorMotor.conveyorOff();
    Serial.println("auto: Conveyor OFF");
  }
  else
  {
    conveyorMotor.conveyorOn();
    Serial.println("auto: Conveyor ON");
  }

  delay(300);
}
